import shape from "./basicshape.js";


export default class zShape extends shape{
    constructor(props)
    {
        super(props);
        
        this.setData(this.initialData);

        let arr = this.data;

        const left = (arr[0].x + arr[0].width);
        const top  = (arr[0].y + arr[0].height);
        arr[1] ={...arr[1], x:left,y:top};
    }
    
    initialData = [
        {
          x: this.convertToPixels(0),
          y: this.convertToPixels(0),
          width: this.convertToPixels( 2.5),   //WIDTH IN SQ METER (1 SQUERE METER)
          height: this.convertToPixels( 3.5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
          stroke: 'red',
          strokeWidth: 1,
          fillLinearGradientStartPointX:1,
          fill: this.bgColor,
          id: 'rect1'
        },
        {
            x: this.convertToPixels(0),
            y: this.convertToPixels(0),
            width: this.convertToPixels( 2.5),   //WIDTH IN SQ METER (1 SQUERE METER)
            height: this.convertToPixels( 3.5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
            stroke: 'red',
            strokeWidth: 1,
            fillLinearGradientStartPointX:1,
            fill: this.bgColor,
            id: 'rect2'
          }
      ];
};  