import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import ImageMapper from 'react-image-mapper';

const IMAGE_URL = 'http://www.amikasa.com/images/home-figure-1.png';

const AREAS_MAP = {
  name: "my-map",
  areas: [
    { name: "1", shape: "poly", coords: [81,140,81,54,157,12,236,54,236,143,157,184,81,140], fillColor: "#0003", href : "#" },
    { name: "2", shape: "poly", coords: [234,140,234,54,309,12,384,54,384,140,309,185,234,140], fillColor: "#0003" ,href : "#" },
    { name: "3", shape: "poly", coords: [310,272,310,185,383,142,459,185,459,272,383,315,310,272], fillColor: "#0003",href : "#"  },
    { name: "4", shape: "poly", coords: [234,403,234,315,310,272,383,315,383,403,310,446,234,403], fillColor: "#0003",href : "#"  },
    { name: "4", shape: "poly", coords: [81,402,81,316,158,274,233,316,233,402,158,445,81,402], fillColor: "#0003",href : "#"  },
    { name: "4", shape: "poly", coords: [8,273,8,186,84,143,156,186,156,273,84,315,8,273], fillColor: "#0003",href : "#"  },
    { name: "4", shape: "poly", coords: [], fillColor: "#0003"  },
    { name: "5", shape: "circle", coords: [170, 100, 25 ] },
  ]
};

ReactDOM.render(
  <ImageMapper src={IMAGE_URL} map={AREAS_MAP}/>,
  // <React.StrictMode>
  //   <App />
  // </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
