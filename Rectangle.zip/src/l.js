import shape from "./basicshape.js";


export default class lShape extends shape{
    constructor(props)
    {
        super(props)
        let arr = this.data;

        const left = arr[0].x;
        const top  = (arr[0].y + arr[0].height);
        arr[1] ={...arr[1], x:left,y:top};
    }
    data = [
        {
            x: this.convertToPixels(0),
            y: this.convertToPixels( 0),
            width: this.convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
            height: this.convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
            stroke: 'red',
            strokeWidth: 1,
            fillLinearGradientStartPointX:1,
            fill: this.bgColor,
            id: 'rect1'
          },
          {
              x: this.convertToPixels(0),
              y: this.convertToPixels(2.5),
              width: this.convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
              height: this.convertToPixels( 2),                  //HEIGHT IN SQ METER (1 SQUERE METER)
              stroke: 'red',
              strokeWidth: 1,
              fillLinearGradientStartPointX:1,
              fill: this.bgColor,
              id: 'rect2'
            }
      ];
};  