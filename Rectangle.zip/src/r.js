import shape from "./basicshape.js";


export default class rShape extends shape{
    constructor(props)
    {
        super(props)
    }
    data = [
      {
        x: 0,
        y: 0,
        width: this.convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
        height: this.convertToPixels( 7),                  //HEIGHT IN SQ METER (1 SQUERE METER)
        stroke: 'red',
        strokeWidth: 1,
        fillLinearGradientStartPointX:1,
        id: 'rect1',
        fill: this.bgColor
      }
    ];
};  
