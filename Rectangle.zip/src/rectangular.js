import React from 'react';
import RectangularShape from './rectangle.js'
import shape from './shape.js'

const layout = () => {
    return (<RectangularShape data={shape.rectangular}/>);
  };

export default layout;