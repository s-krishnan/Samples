import React from 'react';
import { render } from 'react-dom';
import { Stage, Layer, Rect, Line, Group, Text, Transformer } from 'react-konva';
import RectangularShape from './rectangle.js'
//import shape from './shape.js'
import tShape from './t.js';
import uShape from './u.js';
import zShape from './z.js';
import lShape from './l.js';
import rShape from './r.js';

//render(<RectangularShape data={shape.rectangular}/>, document.getElementById('root'));
//render(<RectangularShape data={new tShape()}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.constructTShape(shape.T)}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.constructUShape(shape.U)}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.constructLShape(shape.L)}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.constructZShape(shape.Z)}/>, document.getElementById('root'));

render(<RectangularShape data={new zShape()} />, document.getElementById('root'));