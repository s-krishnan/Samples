import React from 'react';
import { render } from 'react-dom';
import { Stage, Layer, Rect, Line, Group, Text, Transformer } from 'react-konva';

const SQMT_PX_RATIO=50;

const convertToSQMT = (w) =>{ return Math.round(w / SQMT_PX_RATIO) };

const convertToPixels = (w) =>{ return Math.round(w * SQMT_PX_RATIO)};


const pattern =()=> {
  return (<Rect x={0} y={0} width={1} height={1}/>)
};


const Rectangle = ({ shapeProps, isSelected, onSelect, onChange }) => {
  const shapeRef = React.useRef();
  const trRef = React.useRef();


  React.useEffect(() => {
    if (isSelected) {
      // we need to attach transformer manually
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  const calcTransformedWidth = (node) => {
    return Math.round( (convertToSQMT( node.width() * node.scaleX())) );  
  };

  const calcTransformedHeight = (node) => {
    return Math.round( (convertToSQMT( node.height() * node.scaleY() )));  
  };

  const calcTransformedArea = (node) => {
    return calcTransformedWidth(node) * calcTransformedHeight(node);  
  };

  const fillShapeWithText = (node) => { 
    return showLabel(calcTransformedWidth(node),calcTransformedHeight(node),calcTransformedArea(node));
    //return "".concat(calcWidth(node).toString()," X ",calcHeight(node).toString(), " = ", CalculateArea(node).toString());
  };

  const showLabel = (w,h,a) => { 
    return `${w.toString()}m (l) X ${h.toString()}m (w)  = ${a.toString()}sq.m`;
  };

  return (
    <React.Fragment>
      <Group         
        ref={shapeRef}
        {...shapeProps}
        draggable
        onClick={onSelect}
          onTap={onSelect}
          onTransform={e => {
            const node = shapeRef.current;
            const scaleX = node.scaleX();
            const scaleY = node.scaleY();
          }}
          onTransform = {e => {
            const node = shapeRef.current;
            //const area = ConvertWidth2SQMT(node.width() * node.scaleX());
            const label = node.children[1]  //This needs to be changed
            label.text(
              fillShapeWithText(node) 
            ); 
          }}
          onTransformEnd={e => {
            const node = shapeRef.current;
            //const area = ConvertWidth2SQMT(node.width() * node.scaleX());
            const label = node.children[1]  //This needs to be changed
            label.text(
              fillShapeWithText(node) 
            );
            
            // // transformer is changing scale of the node
            // // and NOT its width or height
            // // but in the store we have only width and height
            // // to match the data better we will reset scale on transform end
            // const node = shapeRef.current;
            // const scaleX = node.scaleX();
            // const scaleY = node.scaleY();
            // onScaleEnd(scaleX,scaleY);

            // // we will reset it back
            // node.scaleX(1);
            // node.scaleY(1);
            // onChange({
            //   ...shapeProps,
            //   x: node.x(),
            //   y: node.y(),
            //   // set minimal value
            //   width: Math.max(5, node.width() * scaleX),
            //   height: Math.max(node.height() * scaleY)
            // });
          }}
        >
        <Rect
          //onClick={onSelect}
          //onTap={onSelect}
          //ref={shapeRef}
          {...shapeProps}
          draggable
          onDragEnd={e => {
            onChange({
              ...shapeProps,
              x: e.target.x(),
              y: e.target.y()
            });
          }}
        />
        <Text 
          {...shapeProps}
          text={
            showLabel(
              convertToSQMT( shapeProps.width) ,
              convertToSQMT( shapeProps.height),
              convertToSQMT( shapeProps.width) * convertToSQMT( shapeProps.height)
              )
            } 
          fontSize = {18}
          fontFamily= {'Calibri'}
          fill = {'#ffffff'}
          align = {'center'}
          verticalAlign = {'middle'}
        />
        </Group> 
      {isSelected && (
        <Transformer
          ref={trRef}
          boundBoxFunc={(oldBox, newBox) => {
            // limit resize
            // if (newBox.width < 5 || newBox.height < 5) {
            //   return oldBox;
            // }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
};


const Polygon = ({ shapeProps, isSelected, onSelect, onChange,onScaleEnd }) => {
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (isSelected) {
      // we need to attach transformer manually
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  return (
    <React.Fragment>
      <Line
        onClick={onSelect}
        onTap={onSelect}
        ref={shapeRef}
        {...shapeProps}
        draggable
        onDragEnd={e => {
          onChange({
            ...shapeProps,
            x: e.target.x(),
            y: e.target.y()
          });
        }}
        onTransformEnd={e => {
          // transformer is changing scale of the node
          // and NOT its width or height
          // but in the store we have only width and height
          // to match the data better we will reset scale on transform end
          const node = shapeRef.current;
          const scaleX = node.scaleX();
          const scaleY = node.scaleY();
          
          onScaleEnd(scaleX,scaleY);
          //this.setY(scaleY);
          // we will reset it back
          node.scaleX(1);
          node.scaleY(1);
          onChange({
            ...shapeProps,
            x: node.x(),
            y: node.y(),
            // set minimal value
            width: Math.max(5, node.width() * scaleX),
            height: Math.max(node.height() * scaleY)
          });
        }}
      />
      {isSelected && (
        <Transformer
        ref={trRef}
        boundBoxFunc={(oldBox, newBox) => {
          // limit resize
          if (newBox.width < 5 || newBox.height < 5) {
            return oldBox;
          }
          return newBox;
        }}
      />
      )}
    </React.Fragment>
  );
};

const initialRectangles = [
  {
    x: 0,
    y: 0,
    width: convertToPixels( 10),   //WIDTH IN SQ METER (1 SQUERE METER)
    height: convertToPixels( 7),                  //HEIGHT IN SQ METER (1 SQUERE METER)
    stroke: 'red',
    strokeWidth: 1,
    fillLinearGradientStartPointX:1,
    id: 'rect1'
  }
];

const initialPolygons = [
  // {
  //   points: 
  //   [ 40,40,
  //     160,40,
  //     160,80,
  //     40,80,
  //     40,40
  //   ],
  //   fill: '#00D2FF',
  //   stroke: 'black',
  //   strokeWidth: 1,
  //   closed: true,
  //   id: 'poly1'
  // },
  // {
  //   points: 
  //   [ 200,40,
  //     320,40,
  //     320,80,
  //     280,80,
  //     280,160,
  //     240,160,
  //     240,80,
  //     200,80,
  //     200,40
  //   ],
  //   fill: '#00D2FF',
  //   stroke: 'black',
  //   strokeWidth: 1,
  //   closed: true,
  //   id: 'poly0'
  // },
  // {
  //   points: 
  //   [ 
  //     120,80,
  //     120,160,
  //     80,160,
  //     80,80
  //   ],
  //   fill: '#00D2FF',
  //   stroke: 'black',
  //   strokeWidth: 1,
  //   closed: true,
  //   id: 'poly2'
  // }
];

const App = () => {
  const [rectangles, setRectangles] = React.useState(initialRectangles);
  const [selectedId, selectShape] = React.useState(null);

  const [polygons, setPolygons] = React.useState(initialPolygons);
  const [selectedPolyId, selectPoly] = React.useState(null);

  const checkDeselect = e => {
    // deselect when clicked on empty area
    const clickedOnEmpty = e.target === e.target.getStage();
    if (clickedOnEmpty) {
      selectShape(null);
      selectPoly(null);
    }
  };

  return (
    <div>
    <Stage
      width={window.innerWidth}
      height={window.innerHeight}
      onMouseDown={checkDeselect}
      onTouchStart={checkDeselect}
    >
      <Layer>
        {rectangles.map((rect, i) => {
          return (
            <Rectangle
              key={i}
              shapeProps={rect}
              isSelected={rect.id === selectedId}
              onSelect={() => {
                selectShape(rect.id);
              }}
              onChange={newAttrs => {
                const rects = rectangles.slice();
                rects[i] = newAttrs;
                setRectangles(rects);
              }}
            />
          );
        })}
      </Layer>

      <Layer>
        {polygons.map((poly, i) => {
          return (
            <Polygon
              key={i}
              shapeProps={poly}
              isSelected={poly.id === selectedPolyId}
              onSelect={() => {
                selectPoly(poly.id);
              }}
              onChange={newAttrs => {
                const polys = polygons.slice();
                polys[i] = newAttrs;
                setPolygons(polys);
              }}
            />
          );
        })}
      </Layer>

    </Stage>
    </div>
  );
};

render(<App />, document.getElementById('root'));