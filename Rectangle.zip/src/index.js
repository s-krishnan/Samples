import React from 'react';
import { render } from 'react-dom';
import { Stage, Layer, Rect, Line, Group, Text, Transformer } from 'react-konva';
import RectangularShape from './rectangle.js'
import shape from './shape.js'

//render(<RectangularShape data={shape.rectangular}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.T}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.U}/>, document.getElementById('root'));
//render(<RectangularShape data={shape.L}/>, document.getElementById('root'));
render(<RectangularShape data={shape.rectangular}/>, document.getElementById('root'));