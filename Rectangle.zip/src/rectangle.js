import React from 'react';
import { render } from 'react-dom';
import { Stage, Layer, Rect, Line, Group, Text, Transformer } from 'react-konva';
//import shape from './shape.js';
import _ from 'underscore'
import basicShape from './basicshape.js'

const pattern =()=> {
  return (<Rect x={0} y={0} width={1} height={1}/>)
};

const Rectangle = ({ shapeProps, isSelected, onSelect, onChange }) => {

  const shapeRef = React.useRef();
  const trRef = React.useRef();
  const shape = new basicShape();

  React.useEffect(() => {
    if (isSelected) {
      // we need to attach transformer manually
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  const calcTransformedWidth = (node) => {
    return Math.round( (shape.convertToSQMT( node.width * node.scaleX)) );
  };

  const calcTransformedHeight = (node) => {
    return Math.round( (shape.convertToSQMT( node.height * node.scaleY )));  
  };

  const calcTransformedArea = (node) => {
    return calcTransformedWidth(node) * calcTransformedHeight(node);  
  };

  const fillShapeWithText = (node) => { 
    return showLabel(calcTransformedWidth(node),calcTransformedHeight(node),calcTransformedArea(node));
    //return "".concat(calcWidth(node).toString()," X ",calcHeight(node).toString(), " = ", CalculateArea(node).toString());
  };

  const showLabel = (w,h,a) => { 
    return `${w.toString()}m (l) X ${h.toString()}m (w)  = ${a.toString()}sq.m`;
  };

  const handleTransform = (e) => {
    //const area = ConvertWidth2SQMT(node.width() * node.scaleX());
    const label = e.target.getChildren(function(node){
      return node.getClassName() === 'Text';
   });  
    const node = e.target.getChildren(function(node){
      return node.getClassName() === 'Rect';
   });  
    label[0].text(
      fillShapeWithText(
          { 
            width:node[0].width(), 
            height:node[0].height(),
            scaleX: e.target.scaleX(),
            scaleY : e.target.scaleY()
           }
        ) 
    );
  };
  const handleTransformEnd = (e) => {
    
    handleTransform(e);

    const node = e.target.getChildren(function(node){
      return node.getClassName() === 'Rect';
    });
    
    onChange({
      x: node[0].x(),
      y: node[0].y(),
      width:node[0].width() * node[0].scaleX(),
      height:node[0].height() * node[0].scaleY()
    });
  }
  const  displayText= showLabel(
    shape.convertToSQMT( shapeProps.width) ,
    shape.convertToSQMT( shapeProps.height),
    shape.convertToSQMT( shapeProps.width) * shape.convertToSQMT( shapeProps.height)
    );
  return (
    <React.Fragment>
      <Group         
        ref={shapeRef}
        //draggable
          onClick={onSelect}
          onTap={onSelect}
          //{...shapeProps}
          onTransform ={handleTransform}
          onTransformEnd ={handleTransformEnd}
        >
        <Rect
          //onClick={onSelect}
          //onTap={onSelect}
          //ref={shapeRef}
          {...shapeProps}
          onDragEnd={e => {
            onChange({
              ...shapeProps,
              x: e.target.x(),
              y: e.target.y()
            });
          }}
        />
        <Text 
          {...shapeProps}
          text={displayText} 
          fontSize = {18}
          fontFamily= {'Calibri'}
          fill = {'#ffffff'}
          align = {'center'}
          verticalAlign = {'middle'}
        />
        </Group> 
      {isSelected && (
        <Transformer
          ref={trRef}
          boundBoxFunc={(oldBox, newBox) => {
            // limit resize
            // if (newBox.width < 5 || newBox.height < 5) {
            //   return oldBox;
            // }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
};

{

}




class RectangularShape extends React.Component {
  
  _element = React.createRef();
  layerRef = React.createRef();

  setRectangles(data){

    this.setState ( {...this.state, rectangles: data });
    if(this.props.onChange){
      this.props.onChange(this.state.rectangles);
    }
  }

  selectShape(id){
    this.setState({...this.state, selectedId: id });    
  }

  checkDeselect(e) {
    // deselect when clicked on empty area
    const clickedOnEmpty = e.target === e.target.getStage();
    if (clickedOnEmpty) {
          this.selectShape(null);
    }
  };

  componentDidMount()   {
    //const screenSize = this._element.current.getSize();             
    // const tempRect = this.state.rectangles.map(rect =>{       
    //   rect.x = (this._element.current.clientWidth - rect.width)/2;       
    //   rect.y = (this._element.current.clientHeight - rect.height)/2;       
    //   return rect;     
    // });          
    
    //this.setRectangles(tempRect);     
    this.setState({       ...this.state,      
      stageWidth: this._element.current.clientWidth,       
      stageHeight: this._element.current.clientHeight
    });   

    const rectangles = this.state.rectangles;
    const screenCanvas = this.layerRef.current;
    // const screenSize = screenCanvas.getSize();
    const screenSize = {width:this._element.current.clientWidth,
      height:this._element.current.clientHeight}

    // const tempRect = this.state.rectangles.map(rect =>{              
    //   rect.x = (screenSize.width - rect.width)/2;
    //   rect.y = (screenSize.height - rect.height)/2;
    //   return rect;     
    // });      
    //this.setRectangles(tempRect);

    const minLeft = _.min(rectangles,n=>n.x);
    const minTop =_.min(rectangles,n=>n.y);
    const maxRight = _.max(rectangles,n=>n.x+n.width);
    const maxBottom = _.max(rectangles,n=>n.y+n.height); 
    const maxDrawWidth =  (maxRight.x+maxRight.width) - minLeft.x;
    const maxDrawHeight = (maxBottom.y+maxBottom.height) - minTop.y;

    screenCanvas.offsetX(-1*(screenSize.width-maxDrawWidth)/2);
    screenCanvas.offsetY(-1*(screenSize.height -maxDrawHeight)/2);

  }

  constructor(props) {
    super(props);
    // Don't call this.setState() here!
    
    this.state = {rectangles : props.data.data} ;
    this.state.selectedId =  null; 
    
    this.setRectangles = this.setRectangles.bind(this);
    this.selectShape = this.selectShape.bind(this);
    this.checkDeselect = this.checkDeselect.bind(this);

  }

  render(){

  return (
    <div  ref={this._element} style={{width:window.innerWidth},{height: window.innerHeight}}>
    <Stage
      width=  {this.state.stageWidth}   //{window.innerWidth}
      height=  {this.state.stageHeight} //{window.innerHeight}
      onMouseDown={this.checkDeselect}
      onTouchStart={this.checkDeselect}
    >
      <Layer ref={this.layerRef}>
        <Group>
        {this.state.rectangles.map((rect, i) => {
          return (
            <Rectangle
              key={i}
              shapeProps={rect}
              isSelected={rect.id === this.state.selectedId}
              onSelect = {(e) => this.selectShape(rect.id)}
              onChange={newAttrs => {
                const rects = this.state.rectangles.slice();
                rects[i] = {...rects[i], newAttrs};
                this.setRectangles(rects);
              }}
            />
          );
        })}
        </Group>
      </Layer>
    </Stage>
    </div>
  );
      }
}; 

export default RectangularShape;