import shape from "./basicshape.js";


export default class tShape extends shape{
    constructor(props)
    {
        super(props)
        let arr = this.data; 

        //build L shape
        const left0 = arr[0].x;
        const top0  = (arr[0].y + arr[0].height);
        arr[1] ={...arr[1], x:left0,y:top0};

        //build U Shape
        const left1 = arr[1].x+arr[1].width-arr[2].width;
        const top1  = arr[1].y-arr[2].height;
        arr[2] ={...arr[2], x:left1,y:top1};
    }
    data = [
        {
          x: this.convertToPixels(0),
          y: this.convertToPixels( 0),
          width: this.convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
          height: this.convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
          stroke: 'red',
          strokeWidth: 1,
          fillLinearGradientStartPointX:1,
          fill: this.bgColor,
          id: 'rect1'
        },
        {
            x: this.convertToPixels(0),
            y: this.convertToPixels(2.5),
            width: this.convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
            height: this.convertToPixels( 2),                  //HEIGHT IN SQ METER (1 SQUERE METER)
            stroke: 'red',
            strokeWidth: 1,
            fillLinearGradientStartPointX:1,
            fill: this.bgColor,
            id: 'rect3'
          },
          {
            x: this.convertToPixels(1.5),
            y: this.convertToPixels( 0),
            width: this.convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
            height: this.convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
            stroke: 'red',
            strokeWidth: 1,
            fillLinearGradientStartPointX:1,
            fill: this.bgColor,
            id: 'rect2'
          }
      ];
};  