const SQMT_PX_RATIO=50;

const convertToSQMT = (w) =>{ return w /SQMT_PX_RATIO };

const convertToPixels = (w) =>{ return w * SQMT_PX_RATIO};

const rectangular = [
    {
      x: 0,
      y: 0,
      width: convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
      height: convertToPixels( 7),                  //HEIGHT IN SQ METER (1 SQUERE METER)
      stroke: 'red',
      strokeWidth: 1,
      fillLinearGradientStartPointX:1,
      id: 'rect1',
      fill:'#feab'
    }
  ];

  const Z = [
    {
      x: convertToPixels(0),
      y: convertToPixels(0),
      width: convertToPixels( 2.5),   //WIDTH IN SQ METER (1 SQUERE METER)
      height: convertToPixels( 3.5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
      stroke: 'red',
      strokeWidth: 1,
      fillLinearGradientStartPointX:1,
      id: 'rect1'
    },
    {
        x: convertToPixels(0),
        y: convertToPixels(0),
        width: convertToPixels( 2.5),   //WIDTH IN SQ METER (1 SQUERE METER)
        height: convertToPixels( 3.5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
        stroke: 'red',
        strokeWidth: 1,
        fillLinearGradientStartPointX:1,
        id: 'rect2'
      }
  ];

  const constructZShape = (arr) =>{ 
    // if (_.isEmpty(arr) || !_.isArray(arr))
    //   return [];
    const left = (arr[0].x + arr[0].width);
    const top  = (arr[0].y + arr[0].height);
    arr[1] ={...arr[1], x:left,y:top};
    return arr; 
  };

  const T = [
    {
      x: convertToPixels(0),
      y: convertToPixels(0),
      width: convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
      height: convertToPixels( 2),                  //HEIGHT IN SQ METER (1 SQUERE METER)
      stroke: 'red',
      strokeWidth: 1,
      fillLinearGradientStartPointX:1,
      id: 'rect1'
    },
    {
      x: convertToPixels(0),
      y: convertToPixels(0),
      width: convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
      height: convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
      stroke: 'red',
      strokeWidth: 1,
      fillLinearGradientStartPointX:1,
      id: 'rect2'
    }
  ];

  const constructTShape = (arr) =>{ 
        // if (_.isEmpty(arr) || !_.isArray(arr))
    //   return [];
      const left = ((arr[0].x + arr[0].width)-arr[1].width)/2;
      const top  = (arr[0].y + arr[0].height);
      arr[1] ={...arr[1], x:left,y:top};
    return arr; 
  };

  const L = [
    {
        x: convertToPixels(0),
        y: convertToPixels( 0),
        width: convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
        height: convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
        stroke: 'red',
        strokeWidth: 1,
        fillLinearGradientStartPointX:1,
        id: 'rect1'
      },
      {
          x: convertToPixels(0),
          y: convertToPixels(2.5),
          width: convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
          height: convertToPixels( 2),                  //HEIGHT IN SQ METER (1 SQUERE METER)
          stroke: 'red',
          strokeWidth: 1,
          fillLinearGradientStartPointX:1,
          id: 'rect2'
        }
  ];

  const constructLShape = (arr) =>{ 
    // if (_.isEmpty(arr) || !_.isArray(arr))
    //   return [];
    const left = arr[0].x;
    const top  = (arr[0].y + arr[0].height);
    arr[1] ={...arr[1], x:left,y:top};
    return arr; 
  };

  const U = [
    {
      x: convertToPixels(0),
      y: convertToPixels( 0),
      width: convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
      height: convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
      stroke: 'red',
      strokeWidth: 1,
      fillLinearGradientStartPointX:1,
      id: 'rect1'
    },
    {
        x: convertToPixels(0),
        y: convertToPixels(2.5),
        width: convertToPixels( 5),   //WIDTH IN SQ METER (1 SQUERE METER)
        height: convertToPixels( 2),                  //HEIGHT IN SQ METER (1 SQUERE METER)
        stroke: 'red',
        strokeWidth: 1,
        fillLinearGradientStartPointX:1,
        id: 'rect3'
      },
      {
        x: convertToPixels(1.5),
        y: convertToPixels( 0),
        width: convertToPixels( 2),   //WIDTH IN SQ METER (1 SQUERE METER)
        height: convertToPixels( 5),                  //HEIGHT IN SQ METER (1 SQUERE METER)
        stroke: 'red',
        strokeWidth: 1,
        fillLinearGradientStartPointX:1,
        id: 'rect2'
      }
  ];
  const constructUShape = (arr) =>{ 
    // if (_.isEmpty(arr) || !_.isArray(arr))
    //   return [];
    let lShape = constructLShape(arr);
    const left = lShape[1].x+lShape[1].width-arr[2].width;
    const top  = lShape[1].y-arr[2].height;
    lShape[2] ={...lShape[2], x:left,y:top};
    return lShape; 
  };

exports.convertToSQMT = convertToSQMT;
exports.convertToPixels = convertToPixels;
exports.rectangular = rectangular;
exports.T = T;
exports.U = U;
exports.L = L;
exports.Z = Z;
exports.constructTShape = constructTShape;
exports.constructZShape = constructZShape;
exports.constructLShape = constructLShape;
exports.constructUShape = constructUShape;