export default class shape{
  
  SQMT_PX_RATIO=50;

  bgColor = '#feab';
  
  convertToSQMT = (w) =>{ return w /this.SQMT_PX_RATIO };  
  
  convertToPixels = (w) =>{ return w * this.SQMT_PX_RATIO};   

  }